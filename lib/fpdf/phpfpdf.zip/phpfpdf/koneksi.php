<?php
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "tutorial";
$connect    = mysqli_connect($host, $user, $password, $database);
?>
